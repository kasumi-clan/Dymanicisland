# Cài đặt APK

1. Lấy `app-debug.apk` (xem `BUILD.md`), chép vào điện thoại (Galaxy A57 hoặc máy Android 10+; **Android 13+ để dùng shader GPU**).
2. Mở file APK → nếu hỏi, cho phép **Cài ứng dụng không rõ nguồn** cho trình duyệt/Files.
3. Samsung/Play Protect có thể cảnh báo vì đây là bản debug tự ký — chọn **Vẫn cài**.
4. Mở **Godly Island** → bấm **Mở Test Mode**.

Phase 2 **không xin quyền nào**. Gỡ cài đặt bình thường như mọi app.
