# Hướng dẫn gỡ lỗi

## Trong app
Test Mode → cuối trang **Error log** (10 dòng gần nhất) và **Shader compile** từng mức Low/Balanced/Ultra.

## Qua adb
```
adb logcat -s GodlyIsland
```
Mọi lỗi shader/test được ghi với tag `GodlyIsland`.

## Lỗi thường gặp

| Hiện tượng | Nguyên nhân khả dĩ | Làm gì |
|---|---|---|
| Workflow đỏ ở bước *Build debug APK* | Lỗi biên dịch Kotlin (chưa từng build) | Copy dòng `e: file:///...` gửi lại để sửa |
| "Shader ... LỖI: ..." trong Test Mode | AGSL sai cú pháp trên máy | Gửi nguyên dòng lỗi; app tự dùng Canvas |
| "Shader ... Không hỗ trợ" | Android < 13 | Bình thường, dùng Canvas |
| FPS = 0 | Màn hình đứng yên → hệ thống không tạo frame | Bật "Ripple động" hoặc chạy Test Animation |
| GPU time "không có" | Android < 12 | Bình thường |
| Khung Shader giống hệt Canvas | Shader không biên dịch, đang fallback | Xem dòng "Current renderer" |
