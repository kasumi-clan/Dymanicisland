# Hướng dẫn quyền

**Phase 2: không cần quyền nào.**

Các quyền sẽ xuất hiện ở phase sau — chỉ xin khi tính năng cần, người dùng tự bật, không bypass bảo mật Android:

| Quyền | Dùng cho | Phase | Cách bật |
|---|---|---|---|
| Hiển thị trên ứng dụng khác (`SYSTEM_ALERT_WINDOW`) | Vẽ Island | 4 | Cài đặt → Ứng dụng → Godly Island → Hiển thị trên các ứng dụng khác |
| Truy cập thông báo (`NotificationListenerService`) | Thông báo, nhạc (MediaSession), điều hướng Maps | 5–6 | Cài đặt → Thông báo → Truy cập thông báo |
| Thông báo (Android 13+, `POST_NOTIFICATIONS`) | Foreground service | 4 | Hộp thoại hệ thống |
| Foreground service | Giữ Island sống | 4 | Tự động khi bật Island |
| Bỏ tối ưu pin | Island không bị hệ thống tắt | 4 | Tuỳ chọn, người dùng tự đồng ý |
| Bluetooth (`BLUETOOTH_CONNECT`) | Trạng thái tai nghe | 6 | Hộp thoại hệ thống |
| Điện thoại / Danh bạ | Tên người gọi, trả lời/từ chối | 6 | Chỉ xin nếu cần; Android có thể không cho |

Không có quyền nào đòi hỏi vô lý; không có server; không có API trả phí.
