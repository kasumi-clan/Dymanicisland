# Phase 1 — Phân tích Liquid Glass trong `Godly-Watermark.html`

Tệp 2,3 MB, phần lớn là dữ liệu nhúng (mp3, font Minecraft, logo, ảnh nền). Phần mã thật ~68 KB. Lõi kính nằm ở dòng 205–288.

## Quy trình vẽ gốc

1. Chụp lát nền sau thanh kính (`drawImage` vào canvas phụ).
2. Fragment shader WebGL tính kính trên lát nền đó.
3. Ghép **overlay** (chữ, logo) lên **sau cùng**: `g = v.rgb + g*(1-v.a)` → chữ không bị khúc xạ.
4. Nếu mất context WebGL (`webglcontextlost`) hoặc lỗi → cờ `glbad` → dùng Canvas 2D `fb()`.

## Shader (từng bước)

| Bước | Công thức gốc | Ý nghĩa |
|---|---|---|
| SDF hộp bo góc | `sd(q,hs)` | khoảng cách có dấu tới viền |
| Pháp tuyến | đạo hàm SDF 4 điểm | hướng mặt kính ở mép |
| Độ sâu mép | `t=clamp(-d/(h*.5))`, `rim=pow(1-t,1.7)` | 0 ở giữa → 1 ở mép |
| Khúc xạ "hút vào" | `s=c0+q*mix(.68,.5,rim)-vec2(n.x,n.y*.45)*rim*h*1.25` | giữa phóng to, mép kéo nội dung từ trong ra |
| Gợn lỏng | `sin(...)*h*.06*smoothstep(0,.6,t)` | méo nhẹ theo thời gian `P` |
| Làm nét | `g=c1+(c1-nb)*1.2` | unsharp mask |
| Sáng viền | `sp` (2 mặt trăng lưỡi liềm, hướng sáng `(-.5,-.85)`), `rim*.02`, mép dưới `.05` | phản chiếu |
| Viền 1 px | `exp(-((d+lw*1.2)/lw)^2)*.2` | vệt sáng sát mép |
| Khử răng cưa | `smoothstep(.8,-.8,d)` | |

### Phát hiện quan trọng

- Shader gốc **không có blur**: hàm `bl()` được khai báo nhưng **không được gọi**. Kính gốc là *thấu kính trong suốt + làm nét*, không phải kính mờ.
- Biến `ca` (sắc sai) được tính nhưng **không dùng** → không có viền màu, đúng yêu cầu "không ánh màu" trước đây.
- Vì vậy Godly Island **bổ sung** (đánh dấu NEW trong shader): blur/frost, độ tối AMOLED, độ trong suốt, hệ số phản chiếu/viền/khúc xạ, vệt shine, các mức chất lượng.

### Animation CSS gốc

`pop` (`cubic-bezier(.2,1.2,.3,1)`, nảy quá đà ~5%) · `shine` (dải sáng nghiêng 18° quét 1,1 s) · `drop` · `swap` · `outa`; tắt hết khi `prefers-reduced-motion`.
→ Android: `spring(dampingRatio 0.62)` cho kích thước, `shine` là uniform quét 1 lần, ripple chỉ chạy khi bật.

### Bảng chuyển đổi

| Web | Android |
|---|---|
| WebGL GLSL ES 1.0 | **AGSL** (`RuntimeShader` + `RenderEffect`, Android 13+) — cùng đường GPU, không có EGL context để mất |
| `texture2D(T, s/R)` | `content.eval(pixel)` |
| texture overlay `O` | lớp Compose vẽ **trên** lớp kính (không bị khúc xạ) |
| Canvas 2D `fb()` (64 lát phóng 0,58×) | Canvas Compose: thân tối + ánh sáng trên + viền gradient (không khúc xạ/blur) |
| `glbad` | `GlassEngine.ready` → false khi lỗi, tự chuyển Canvas |
| `lens` | `GlassConfig.lens` |

## Giới hạn Android phải nói thẳng

Cửa sổ overlay **không thể đọc pixel của app phía sau** (không có API, trừ MediaProjection — bị loại vì hiện biểu tượng ghi màn hình và xin quyền quay). Vì vậy:

- Khúc xạ tác động lên **nền riêng của Island** (gradient tối / ảnh album làm mờ), không phải màn hình thật phía sau.
- Blur nền thật qua `setBlurBehindRadius` (Android 12+) là phương án **thử ở Phase 4**; không đảm bảo trên mọi máy.

## Kiểm chứng đã làm

Port được chuyển sang GLSL ES 3.0 và chạy trong Chromium (WebGL2) cùng nền thử với shader gốc (WebGL1), tham số trung hoà:

- ULTRA vs gốc: sai khác trung bình **0,054 / 255**, 0,54% điểm ảnh lệch >8 (chỉ ở hàng trên/dưới cùng do cách kẹp toạ độ biên).
- LOW / BALANCED khác gốc có chủ đích (bỏ gợn, bỏ làm nét).
- Cả 3 mức biên dịch và vẽ được. Ảnh: `docs/shader_check_sheet.png`.

**Chưa kiểm chứng:** cú pháp SkSL/AGSL trên Android thật (Android tự biên dịch lúc chạy). Test Mode hiển thị "Shader compile" từng mức để xác nhận.
