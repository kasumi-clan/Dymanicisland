# Hướng dẫn test (Phase 3)

Sau khi cài APK (`INSTALL.md`):

1. Mở app → xem thẻ **Trạng thái thiết bị**: "Shader AGSL: được hỗ trợ" và "Biên dịch shader …: OK".
   Nếu màu vàng/không dùng được → chụp màn hình, dừng ở đây.
2. **Mở Test Mode** → bấm **Run All Tests** (~20 giây, đừng chạm màn hình).
3. Xem mục **Kết quả kiểm tra**. Cần: Shader Low/Balanced/Ultra = PASS, Canvas fallback = PASS, Auto-fallback = PASS. Animation/Performance = PASS hoặc SKIP (kèm lý do).
4. Nhìn bằng mắt (quan trọng, máy không tự đánh giá được):
   - Khung **Shader** và **Canvas** phải khác nhau: Shader có méo khúc xạ ở mép và viền sáng; Canvas chỉ tối + viền.
   - Island Mini → Expanded → Full → Dual chuyển mượt, có nảy nhẹ, không giật.
   - Chữ trên Island luôn nét (không bị méo).
5. Thử tay: vuốt lên trên preview (đóng), nhấn giữ (mở rộng), kéo các thanh trượt, đổi Low/Balanced/Ultra.
6. Bấm **Apply Settings** (chỉ sáng sau khi Test Liquid Glass đạt) → thoát ra, mở lại app: ô preview ở màn hình chính dùng đúng cấu hình đã lưu.

## Gửi lại cho mình
- Ảnh chụp mục Kết quả kiểm tra + Hiệu năng + Error log.
- Mô tả: kính nhìn thế nào so với bản web Godly-Watermark (quá méo? quá tối? quá sáng viền?).

## Tiêu chí đạt
- Không crash, không chữ "FAIL".
- Jank ≤ 20% (khung > 1,5× ngân sách; 120 Hz = 8,3 ms, 60 Hz = 16,7 ms).
- Mắt thấy đúng mục 4.
