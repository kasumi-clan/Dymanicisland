# Kế hoạch triển khai Godly Island

Quy tắc: làm từng phase, không báo "hoạt động" khi chưa test, không placeholder cho tính năng đã yêu cầu.

| Phase | Việc | Kiểm chứng | Trạng thái |
|---|---|---|---|
| 1 | Phân tích `Godly-Watermark.html` | Shader chạy lại trong WebGL, so với bản port | Xong |
| 2 | `LiquidGlassRenderer`, `LiquidGlassPreview`, Test Mode (A, B một phần, C, D, E) | Cần biên dịch + chạy máy thật | Code xong, chưa test |
| 3 | Test Liquid Glass trên Android | Bạn chạy Test Mode, gửi ảnh chụp kết quả | **Bước tiếp theo** |
| 4 | Island Core: `GodlyIslandService`, `IslandWindowManager`, `IslandStateManager`, `IslandAnimationController`, `IslandEventManager`, overlay + quyền overlay | Overlay thật trên A57 | Chưa làm |
| 5 | Notification / Music (MediaSession) / Battery / Timer | Sự kiện thật | Chưa làm |
| 6 | Call / Navigation (từ thông báo Maps) / System | Chỉ trạng thái Android cho phép đọc | Chưa làm |
| 7 | Animation hoàn chỉnh, Dual Island thật, swipe/haptic | Test Mode B | Chưa làm |
| 8 | Tối ưu hiệu năng / pin | Performance Test | Chưa làm |
| 9 | Build APK, README/INSTALL/BUILD đầy đủ | CI xanh | Một phần (workflow đã có) |
| 10 | Test thực tế | Máy thật | Chưa làm |

## Phase 2 — đã làm so với yêu cầu Test Mode

- A. Liquid Glass Test: preview, so sánh Shader | Canvas, blur / trong suốt / phản chiếu / viền / khúc xạ, Low-Balanced-Ultra, kiểm tra biên dịch shader từng mức, fallback.
- B. Island Animation: Mini / Expanded / Full / Dual, spring, shine, ripple, vuốt lên để đóng, nhấn giữ để mở rộng. (Animation của Music/Call/Battery… cần nội dung thật từ Phase 5–6.)
- C. Event Simulator: 11 loại sự kiện + Dual, hoàn toàn trong app, không đụng NotificationManager/Telecom.
- D. Performance: FPS, frame time, draw time, GPU time (Android 12+), bộ nhớ, renderer đang dùng, animation state, event hiện tại, trạng thái compile shader, error log.
- E. Apply: chỉ mở sau khi Test Liquid Glass đạt; Restore Default. "Áp dụng cho Island thật" chờ Phase 4.

## Chưa làm ở Phase 2

Toàn bộ Settings Activity đầy đủ, màn Permission setup, mọi tính năng Island thật.
