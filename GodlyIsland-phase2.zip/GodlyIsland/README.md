# Godly Island

Dynamic Island cho Android (Kotlin + Jetpack Compose) với **Liquid Glass lấy kỹ thuật thật từ `Godly-Watermark.html`**.

## Tình trạng hiện tại (trung thực)

| Phase | Nội dung | Trạng thái |
|---|---|---|
| 1 | Phân tích `Godly-Watermark.html` | **Xong** — xem `docs/ANALYSIS_LIQUID_GLASS.md` |
| 2 | Liquid Glass Preview + Test Mode | **Code xong, CHƯA biên dịch, CHƯA chạy trên điện thoại** |
| 3 | Test Liquid Glass trên Android | Chờ bạn build APK và chạy Test Mode (`docs/TEST_GUIDE.md`) |
| 4–10 | Island thật (overlay), thông báo, nhạc, pin, hẹn giờ, cuộc gọi, điều hướng, hệ thống, tối ưu, build cuối | **Chưa làm** |

Môi trường soạn code này **không có Android SDK, Gradle, trình biên dịch Kotlin và mạng**, nên APK **chưa được build**.
Cái đã kiểm chứng thật: shader Liquid Glass (đã chạy trong Chromium/WebGL, so khớp với shader gốc — sai khác trung bình 0,05/255).
Cái chưa kiểm chứng: biên dịch Kotlin, chạy AGSL trên máy thật. Test Mode trong app sinh ra để kiểm tra đúng những điều đó.

## Có gì trong bản này

- `LiquidGlassRenderer` — 2 đường vẽ: **Shader AGSL** (Android 13+, GPU) và **Canvas** (fallback, Android 10+). 3 mức Low / Balanced / Ultra.
- `Test Mode` — preview Island (Mini / Expanded / Full / Dual) với animation spring, sự kiện **giả lập** (không gửi thông báo/cuộc gọi thật), đo FPS / frame time / GPU time / bộ nhớ thật từ hệ thống, log lỗi, nút Run All / Apply / Reset / Restore Default.
- `Apply Settings` chỉ mở sau khi test Liquid Glass đạt; lưu cấu hình vào SharedPreferences.
- Chưa có: overlay Island thật, NotificationListener, MediaSession, quyền hệ thống (Phase 4+).

## Cấu trúc

```
app/src/main/
  assets/liquid_glass.agsl          shader (port từ WebGL gốc)
  java/com/godly/island/
    MainActivity.kt                 màn hình chính
    core/                           theme, UI chung, ErrorLog, PerfMonitor
    renderer/                       LiquidGlassRenderer, GlassEngine (AGSL), GlassConfig
    island/                         IslandShape, IslandPreview (spring, dual)
    events/                         IslandEvent (model sự kiện)
    settings/                       GlassSettingsStore
    testing/                        GodlyIslandTestActivity, IslandTestPanel, LiquidGlassPreview, IslandEventSimulator
docs/                               phân tích, kế hoạch, hướng dẫn
.github/workflows/build-apk.yml     build APK debug bằng GitHub Actions
```
Các thư mục `notifications/ media/ battery/ navigation/` sẽ được tạo ở Phase 5–6.

## Tài liệu

`BUILD.md` · `INSTALL.md` · `docs/PLAN.md` · `docs/ANALYSIS_LIQUID_GLASS.md` · `docs/PERMISSIONS.md` · `docs/DEBUG.md` · `docs/TEST_GUIDE.md`
