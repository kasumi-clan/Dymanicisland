# Build APK (debug)

Máy soạn code không build được Android, nên dùng **GitHub Actions** (giống các app Godly trước).

## Cách 1 — GitHub Actions (khuyên dùng)

1. Tạo repo GitHub mới (ví dụ `GodlyIsland`).
2. Đưa **toàn bộ** nội dung thư mục này lên repo, **nhớ cả thư mục ẩn `.github`** (chứa file build).
   - Trên Termux:
     ```
     pkg install git unzip
     unzip GodlyIsland.zip && cd GodlyIsland
     git init && git add . && git commit -m "Godly Island phase 2"
     git branch -M main
     git remote add origin https://github.com/<tài-khoản>/GodlyIsland.git
     git push -u origin main
     ```
     (GitHub yêu cầu Personal Access Token thay mật khẩu.)
3. Vào tab **Actions** → workflow **Build Godly Island APK (debug)** → chạy tự động khi push, hoặc bấm **Run workflow**.
4. Khi xong (dấu ✓ xanh) mở lần chạy đó → mục **Artifacts** → tải **GodlyIsland-debug-apk** → giải nén ra `app-debug.apk`.
5. Nếu đỏ ✗: mở bước bị lỗi, copy đoạn log có chữ `error:` / `e: file:///...` gửi lại — hoặc tải artifact `GodlyIsland-build-reports`.

## Cách 2 — Android Studio

Mở thư mục bằng Android Studio (Koala 2024.1+), JDK 17, Gradle 8.9 → `Build > Build APK(s)`.
(Dự án chưa kèm `gradle-wrapper.jar`; Android Studio hoặc `gradle wrapper --gradle-version 8.9` sẽ tạo.)

## Phiên bản dùng

AGP 8.7.3 · Kotlin 2.0.21 · Gradle 8.9 · Compose BOM 2024.10.01 · compileSdk 35 · targetSdk 34 · minSdk 29.

## Kiểm tra sau build (Phase 9)

Gradle build ✓ → Kotlin compile ✓ → Manifest ✓ → cài APK → chạy Test Mode (xem `docs/TEST_GUIDE.md`).
Chưa có kết quả nào trong số này cho đến khi bạn chạy workflow.
