package com.godly.island.renderer

/** LOW = no ripple/blur taps, BALANCED = 5-tap frost + sharpen, ULTRA = 9-tap frost + liquid ripple. */
enum class GlassQuality(val tier: Int, val label: String) {
    LOW(0, "Low"),
    BALANCED(1, "Balanced"),
    ULTRA(2, "Ultra"),
}

/** AUTO = shader when supported (Android 13+) else Canvas. SHADER/CANVAS force a path (shader still falls back to Canvas if it cannot compile). */
enum class RenderMode(val label: String) {
    AUTO("Auto"),
    SHADER("Shader"),
    CANVAS("Canvas"),
}

/**
 * All user-tunable Liquid Glass values.
 *  blur          0..1  frost amount
 *  transparency  0..1  0 = opaque black (AMOLED), 1 = most see-through
 *  reflection    0..2  specular / reflection gain
 *  border        0..2  rim-light / border gain
 *  lens          0..1  edge refraction strength (1 = exactly the Godly-Watermark look)
 */
data class GlassConfig(
    val blur: Float = 0.30f,
    val transparency: Float = 0.25f,
    val reflection: Float = 1.0f,
    val border: Float = 1.0f,
    val lens: Float = 0.7f,
    val quality: GlassQuality = GlassQuality.BALANCED,
    val mode: RenderMode = RenderMode.AUTO,
)

/** Glass shape in layer pixels (top-left origin). r = corner radius. */
data class GlassBox(val x: Float, val y: Float, val w: Float, val h: Float, val r: Float) {
    companion object {
        /** Never produces a zero-size shape (the shader divides by the height). */
        fun safe(x: Float, y: Float, w: Float, h: Float, r: Float): GlassBox {
            val sw = if (w < 2f) 2f else w
            val sh = if (h < 2f) 2f else h
            val maxR = (if (sw < sh) sw else sh) / 2f
            return GlassBox(x, y, sw, sh, r.coerceIn(0f, maxR))
        }
    }
}
