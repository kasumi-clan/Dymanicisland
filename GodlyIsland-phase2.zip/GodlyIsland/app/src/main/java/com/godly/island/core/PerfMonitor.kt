package com.godly.island.core

import android.content.Context
import android.os.Build
import android.os.Debug
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.view.FrameMetrics
import android.view.Window
import android.view.WindowManager
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

data class PerfSnapshot(
    val fps: Float = 0f,
    val frameMs: Float = 0f,
    val drawMs: Float = 0f,
    /** GPU time per frame in ms, or -1 when the device/OS does not report it (needs Android 12+). */
    val gpuMs: Float = -1f,
    val jankPercent: Float = 0f,
    val frames: Int = 0,
    val budgetMs: Float = 16.7f,
    val heapMb: Float = 0f,
    val nativeMb: Float = 0f,
)

/**
 * Real frame statistics from the system (Window.FrameMetrics) — no fake numbers.
 * `live` is refreshed every 500 ms; `resetSession()` / `sessionSnapshot()` measure a test run.
 * When nothing is animating the system produces no frames, so fps is 0 (idle).
 */
class PerfMonitor(private val window: Window) {

    var live by mutableStateOf(PerfSnapshot())
        private set

    private class Acc {
        var frames = 0
        var total = 0L
        var draw = 0L
        var gpu = 0L
        var gpuFrames = 0
        var janks = 0

        fun add(totalNs: Long, drawNs: Long, gpuNs: Long, jank: Boolean) {
            frames++
            total += totalNs
            draw += drawNs
            if (gpuNs >= 0) {
                gpu += gpuNs
                gpuFrames++
            }
            if (jank) janks++
        }

        fun clear() {
            frames = 0
            total = 0L
            draw = 0L
            gpu = 0L
            gpuFrames = 0
            janks = 0
        }
    }

    private val lock = Any()
    private val liveAcc = Acc()
    private val sessionAcc = Acc()
    private val main = Handler(Looper.getMainLooper())
    private var thread: HandlerThread? = null
    private var running = false
    private var budgetMs = 16.7f
    private var liveStart = 0L
    private var sessionStart = 0L

    private val listener = Window.OnFrameMetricsAvailableListener { _, fm, _ ->
        val total = fm.getMetric(FrameMetrics.TOTAL_DURATION)
        val draw = fm.getMetric(FrameMetrics.DRAW_DURATION)
        val gpu = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            fm.getMetric(FrameMetrics.GPU_DURATION)
        } else {
            -1L
        }
        val jank = total.toFloat() > budgetMs * 1_500_000f
        synchronized(lock) {
            liveAcc.add(total, draw, gpu, jank)
            sessionAcc.add(total, draw, gpu, jank)
        }
    }

    private val publish = object : Runnable {
        override fun run() {
            val now = SystemClock.elapsedRealtime()
            val snap = synchronized(lock) {
                val s = toSnapshot(liveAcc, now - liveStart)
                liveAcc.clear()
                s
            }
            liveStart = now
            live = snap
            if (running) main.postDelayed(this, 500)
        }
    }

    fun start() {
        if (running) return
        running = true
        budgetMs = refreshBudgetMs()
        val t = HandlerThread("godly-frame-metrics")
        t.start()
        thread = t
        try {
            window.addOnFrameMetricsAvailableListener(listener, Handler(t.looper))
        } catch (e: Throwable) {
            ErrorLog.add("perf", "FrameMetrics unavailable: ${e.message}")
        }
        liveStart = SystemClock.elapsedRealtime()
        sessionStart = liveStart
        main.postDelayed(publish, 500)
    }

    fun stop() {
        if (!running) return
        running = false
        main.removeCallbacks(publish)
        try {
            window.removeOnFrameMetricsAvailableListener(listener)
        } catch (_: Throwable) {
        }
        thread?.quitSafely()
        thread = null
    }

    fun resetSession() {
        synchronized(lock) { sessionAcc.clear() }
        sessionStart = SystemClock.elapsedRealtime()
    }

    fun sessionSnapshot(): PerfSnapshot {
        val now = SystemClock.elapsedRealtime()
        return synchronized(lock) { toSnapshot(sessionAcc, now - sessionStart) }
    }

    private fun toSnapshot(a: Acc, elapsedMs: Long): PerfSnapshot {
        val ms = if (elapsedMs <= 0L) 1L else elapsedMs
        val n = a.frames
        val rt = Runtime.getRuntime()
        return PerfSnapshot(
            fps = n * 1000f / ms,
            frameMs = if (n > 0) a.total.toFloat() / n / 1_000_000f else 0f,
            drawMs = if (n > 0) a.draw.toFloat() / n / 1_000_000f else 0f,
            gpuMs = if (a.gpuFrames > 0) a.gpu.toFloat() / a.gpuFrames / 1_000_000f else -1f,
            jankPercent = if (n > 0) a.janks * 100f / n else 0f,
            frames = n,
            budgetMs = budgetMs,
            heapMb = (rt.totalMemory() - rt.freeMemory()) / 1048576f,
            nativeMb = Debug.getNativeHeapAllocatedSize() / 1048576f,
        )
    }

    @Suppress("DEPRECATION")
    private fun refreshBudgetMs(): Float {
        return try {
            val wm = window.context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val hz = wm.defaultDisplay.refreshRate
            if (hz > 1f) 1000f / hz else 16.7f
        } catch (_: Throwable) {
            16.7f
        }
    }
}
