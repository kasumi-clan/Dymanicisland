package com.godly.island

import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.godly.island.core.GodlyButton
import com.godly.island.core.GodlyColors
import com.godly.island.core.GodlyTheme
import com.godly.island.core.SectionTitle
import com.godly.island.renderer.GlassConfig
import com.godly.island.renderer.LiquidGlassRenderer
import com.godly.island.renderer.rememberGlassEngine
import com.godly.island.settings.GlassSettingsStore
import com.godly.island.testing.GodlyIslandTestActivity
import com.godly.island.testing.LiquidGlassPreview

class MainActivity : ComponentActivity() {
    private var config by mutableStateOf(GlassConfig())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        config = GlassSettingsStore(this).load()
        setContent {
            GodlyTheme {
                HomeScreen(
                    config = config,
                    onOpenTest = {
                        startActivity(Intent(this@MainActivity, GodlyIslandTestActivity::class.java))
                    },
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        config = GlassSettingsStore(this).load()
    }
}

@Composable
private fun HomeScreen(config: GlassConfig, onOpenTest: () -> Unit) {
    val engine = rememberGlassEngine(config.quality)
    val path = LiquidGlassRenderer.resolve(config, engine)
    val shape = RoundedCornerShape(20.dp)

    Box(Modifier.fillMaxSize().background(GodlyColors.Ink)) {
        Column(
            Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.safeDrawing)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text("Godly Island", color = GodlyColors.Paper, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
            Text(
                "Dynamic Island cho Android với Liquid Glass lấy từ Godly-Watermark.",
                color = GodlyColors.Muted,
                fontSize = 13.sp,
            )

            LiquidGlassPreview(config = config, label = "Cấu hình đang áp dụng")

            Column(
                Modifier
                    .fillMaxWidth()
                    .background(GodlyColors.Panel, shape)
                    .border(1.dp, Color.White.copy(alpha = 0.10f), shape)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                SectionTitle("Trạng thái thiết bị")
                Text("Android API " + Build.VERSION.SDK_INT + " • " + Build.MANUFACTURER + " " + Build.MODEL, color = GodlyColors.Paper, fontSize = 12.sp)
                Text(
                    if (LiquidGlassRenderer.shaderSupported) "Shader AGSL: được hỗ trợ (Android 13+)" else "Shader AGSL: không hỗ trợ → dùng Canvas",
                    color = GodlyColors.Paper,
                    fontSize = 12.sp,
                )
                Text(
                    if (engine.ready) "Biên dịch shader ${config.quality.label}: OK (${engine.compileMillis} ms)"
                    else "Biên dịch shader ${config.quality.label}: không dùng được (" + (engine.error ?: "lỗi") + ")",
                    color = if (engine.ready) GodlyColors.Ok else GodlyColors.Warn,
                    fontSize = 12.sp,
                )
                Text("Renderer đang dùng: " + path.name, color = GodlyColors.Paper, fontSize = 12.sp)
            }

            GodlyButton("Mở Test Mode", onOpenTest, Modifier.fillMaxWidth(), filled = true)

            Column(
                Modifier
                    .fillMaxWidth()
                    .background(GodlyColors.Panel, shape)
                    .border(1.dp, Color.White.copy(alpha = 0.10f), shape)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                SectionTitle("Tiến độ dự án")
                Text("Phase 1 • Phân tích Godly-Watermark.html: xong", color = GodlyColors.Ok, fontSize = 12.sp)
                Text("Phase 2 • Liquid Glass + Test Mode: code xong, cần test trên máy", color = GodlyColors.Warn, fontSize = 12.sp)
                Text("Phase 3 • Test Liquid Glass trên Android: chờ bạn chạy Test Mode", color = GodlyColors.Warn, fontSize = 12.sp)
                Text("Phase 4–10 • Island thật, thông báo, nhạc, pin, cuộc gọi...: chưa làm", color = GodlyColors.Muted, fontSize = 12.sp)
            }
        }
    }
}
