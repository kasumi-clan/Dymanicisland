package com.godly.island.core

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object GodlyColors {
    val Ink = Color(0xFF0B0B0C)
    val Panel = Color(0xFF151517)
    val Paper = Color(0xFFF4F4F2)
    val Muted = Color(0xFF9A9AA0)
    val Glow = Color(0xFFBFD8FF)
    val Ok = Color(0xFF7BE0A4)
    val Bad = Color(0xFFFF6B6B)
    val Warn = Color(0xFFFFC857)
}

@Composable
fun GodlyTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = GodlyColors.Paper,
            onPrimary = GodlyColors.Ink,
            background = GodlyColors.Ink,
            onBackground = GodlyColors.Paper,
            surface = GodlyColors.Panel,
            onSurface = GodlyColors.Paper,
        ),
        content = content,
    )
}
