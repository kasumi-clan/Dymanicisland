package com.godly.island.testing

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import com.godly.island.core.GodlyColors
import com.godly.island.core.GodlyTheme
import com.godly.island.core.PerfMonitor
import com.godly.island.settings.GlassSettingsStore

/** Test Mode screen. Safe sandbox: no real notifications, calls or overlay windows are created here. */
class GodlyIslandTestActivity : ComponentActivity() {
    private lateinit var perf: PerfMonitor

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        perf = PerfMonitor(window)
        val store = GlassSettingsStore(this)
        setContent {
            GodlyTheme {
                Box(Modifier.fillMaxSize().background(GodlyColors.Ink)) {
                    IslandTestPanel(store = store, perf = perf)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        perf.start()
    }

    override fun onPause() {
        perf.stop()
        super.onPause()
    }
}
