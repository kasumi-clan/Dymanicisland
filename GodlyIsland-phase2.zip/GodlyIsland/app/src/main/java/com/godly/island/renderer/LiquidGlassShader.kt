package com.godly.island.renderer

import android.content.Context
import android.graphics.RenderEffect
import android.graphics.RuntimeShader
import android.os.Build
import android.os.Handler
import android.os.Looper
import androidx.annotation.RequiresApi
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.GraphicsLayerScope
import androidx.compose.ui.graphics.asComposeRenderEffect
import com.godly.island.core.ErrorLog

/**
 * Owns one compiled AGSL program (assets/liquid_glass.agsl) for one quality tier.
 * AGSL runs on the same GPU pipeline as OpenGL ES but is owned by the system render thread,
 * so there is no EGL context to lose. Any runtime failure flips [ready] to false and the UI
 * falls back to the Canvas renderer.
 */
class GlassEngine private constructor(
    val quality: GlassQuality,
    private val backend: AgslBackend?,
    /** Why the shader is unavailable (null when it compiled). */
    val error: String?,
    val compileMillis: Long,
) {
    private var failedState by mutableStateOf(false)
    private var failedOnce = false

    /** Average CPU time (microseconds) spent per frame updating uniforms + creating the effect. */
    @Volatile
    var cpuMicros: Float = 0f
        private set

    val ready: Boolean get() = backend != null && !failedState

    /** Called from inside Modifier.graphicsLayer { }. */
    fun render(
        scope: GraphicsLayerScope,
        config: GlassConfig,
        layerW: Float,
        layerH: Float,
        box: GlassBox,
        phase: Float,
        shine: Float,
    ) {
        val b = backend ?: return
        try {
            val t0 = System.nanoTime()
            b.update(config, layerW, layerH, box, phase, shine)
            scope.renderEffect = b.effect()
            val us = (System.nanoTime() - t0) / 1000f
            cpuMicros = if (cpuMicros == 0f) us else cpuMicros * 0.9f + us * 0.1f
        } catch (t: Throwable) {
            fail(t)
        }
    }

    private fun fail(t: Throwable) {
        if (failedOnce) return
        failedOnce = true
        ErrorLog.add("shader", "Runtime failure (${quality.label}): ${t.message}")
        Handler(Looper.getMainLooper()).post { failedState = true }
    }

    companion object {
        private val sources = HashMap<Int, String>()

        /** Compiles the shader for [quality]. Never throws. */
        fun create(context: Context, quality: GlassQuality): GlassEngine {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) {
                return GlassEngine(quality, null, "AGSL needs Android 13+ (API 33)", 0L)
            }
            val t0 = System.nanoTime()
            return try {
                val src = loadSource(context, quality.tier)
                val backend = AgslBackend(src)
                GlassEngine(quality, backend, null, (System.nanoTime() - t0) / 1_000_000)
            } catch (t: Throwable) {
                ErrorLog.add("shader", "Compile ${quality.label} failed: ${t.message}")
                GlassEngine(
                    quality,
                    null,
                    t.message ?: t.javaClass.simpleName,
                    (System.nanoTime() - t0) / 1_000_000,
                )
            }
        }

        private fun loadSource(context: Context, tier: Int): String {
            synchronized(sources) {
                return sources.getOrPut(tier) {
                    val raw = context.applicationContext.assets.open("liquid_glass.agsl")
                        .bufferedReader().use { it.readText() }
                    raw.replace(Regex("const int TIER = \\d+;"), "const int TIER = $tier;")
                }
            }
        }
    }
}

@RequiresApi(Build.VERSION_CODES.TIRAMISU)
internal class AgslBackend(source: String) {
    private val shader = RuntimeShader(source)

    fun update(config: GlassConfig, w: Float, h: Float, box: GlassBox, phase: Float, shine: Float) {
        val blurPx = (config.blur * 0.14f * box.h).coerceIn(0f, 40f)
        val dark = ((1f - config.transparency) * 0.85f).coerceIn(0f, 0.95f)
        val alphaIn = (1f - config.transparency * 0.35f).coerceIn(0.4f, 1f)
        shader.setFloatUniform("res", w, h)
        shader.setFloatUniform("box", box.x, box.y, box.w, box.h)
        shader.setFloatUniform("radius", box.r)
        shader.setFloatUniform("phase", phase)
        shader.setFloatUniform("lens", config.lens)
        shader.setFloatUniform("blurPx", blurPx)
        shader.setFloatUniform("refl", config.reflection)
        shader.setFloatUniform("border", config.border)
        shader.setFloatUniform("dark", dark)
        shader.setFloatUniform("alphaIn", alphaIn)
        shader.setFloatUniform("shine", shine)
    }

    fun effect(): androidx.compose.ui.graphics.RenderEffect {
        return RenderEffect.createRuntimeShaderEffect(shader, "content").asComposeRenderEffect()
    }
}
