package com.godly.island.settings

import android.content.Context
import com.godly.island.renderer.GlassConfig
import com.godly.island.renderer.GlassQuality
import com.godly.island.renderer.RenderMode

/** Persists the *applied* Liquid Glass configuration (what the real Island will use). */
class GlassSettingsStore(context: Context) {
    private val prefs = context.applicationContext
        .getSharedPreferences("godly_island_glass", Context.MODE_PRIVATE)

    fun load(): GlassConfig {
        val d = GlassConfig()
        return GlassConfig(
            blur = prefs.getFloat("blur", d.blur),
            transparency = prefs.getFloat("transparency", d.transparency),
            reflection = prefs.getFloat("reflection", d.reflection),
            border = prefs.getFloat("border", d.border),
            lens = prefs.getFloat("lens", d.lens),
            quality = runCatching {
                GlassQuality.valueOf(prefs.getString("quality", null) ?: d.quality.name)
            }.getOrDefault(d.quality),
            mode = runCatching {
                RenderMode.valueOf(prefs.getString("mode", null) ?: d.mode.name)
            }.getOrDefault(d.mode),
        )
    }

    fun save(c: GlassConfig) {
        prefs.edit()
            .putFloat("blur", c.blur)
            .putFloat("transparency", c.transparency)
            .putFloat("reflection", c.reflection)
            .putFloat("border", c.border)
            .putFloat("lens", c.lens)
            .putString("quality", c.quality.name)
            .putString("mode", c.mode.name)
            .apply()
    }

    fun restoreDefault(): GlassConfig {
        prefs.edit().clear().apply()
        return GlassConfig()
    }
}
