package com.godly.island.testing

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.godly.island.core.GodlyColors
import com.godly.island.renderer.GlassBox
import com.godly.island.renderer.GlassConfig
import com.godly.island.renderer.LiquidGlassRenderer
import com.godly.island.renderer.liquidGlass
import com.godly.island.renderer.rememberGlassEngine

/**
 * High-contrast wallpaper (colour gradient + white stripes + big text) so that refraction,
 * blur and highlights are easy to judge by eye.
 */
@Composable
fun TestBackdrop(modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxSize()
            .background(
                Brush.linearGradient(
                    listOf(
                        Color(0xFFFF5E62),
                        Color(0xFFFFD36E),
                        Color(0xFF3AC7D6),
                        Color(0xFF5B3DF5),
                    ),
                ),
            ),
    ) {
        Row(Modifier.fillMaxSize()) {
            repeat(20) { i ->
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .background(if (i % 2 == 0) Color.White.copy(alpha = 0.55f) else Color.Transparent),
                )
            }
        }
        Text(
            text = "GODLY ISLAND 12345",
            color = Color(0xCC111111),
            fontSize = 30.sp,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.align(Alignment.Center),
        )
    }
}

/** A static glass bar on the test backdrop. Used to compare Shader vs Canvas side by side. */
@Composable
fun LiquidGlassPreview(
    config: GlassConfig,
    label: String,
    modifier: Modifier = Modifier,
    animate: Boolean = false,
) {
    val engine = rememberGlassEngine(config.quality)
    val path = LiquidGlassRenderer.resolve(config, engine)
    val phase = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(animate) {
        if (animate) {
            val t0 = withFrameNanos { it }
            while (true) {
                withFrameNanos { now -> phase.floatValue = (now - t0) / 1_000_000_000f * 0.9f }
            }
        }
    }
    val pillH = with(LocalDensity.current) { 54.dp.toPx() }

    Column(modifier) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(110.dp)
                .clip(RoundedCornerShape(16.dp)),
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .liquidGlass(
                        config = config,
                        engine = engine,
                        box = { s ->
                            GlassBox.safe(s.width * 0.07f, (s.height - pillH) / 2f, s.width * 0.86f, pillH, pillH / 2f)
                        },
                        phase = { phase.floatValue },
                    ),
            ) {
                TestBackdrop()
            }
            Text(
                text = "Godly Island",
                color = Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.align(Alignment.Center),
            )
        }
        Text(
            text = label + " • " + path.name,
            color = GodlyColors.Muted,
            fontSize = 11.sp,
            modifier = Modifier.padding(top = 4.dp),
        )
    }
}
