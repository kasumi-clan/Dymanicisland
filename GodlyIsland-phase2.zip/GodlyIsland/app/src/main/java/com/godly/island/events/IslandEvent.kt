package com.godly.island.events

enum class IslandKind(val glyph: String, val label: String) {
    CALL_INCOMING("☎", "Incoming call"),
    CALL_ONGOING("☎", "Ongoing call"),
    MUSIC("♪", "Music"),
    BATTERY_LOW("▮", "Battery low"),
    CHARGING("⚡", "Charging"),
    NOTIFICATION("✉", "Notification"),
    TIMER("◔", "Timer"),
    NAVIGATION("➤", "Navigation"),
    BLUETOOTH("B", "Bluetooth"),
    DOWNLOAD("↓", "Download"),
    AI_PROCESSING("✦", "AI processing"),
}

/**
 * One thing the Island can show. [simulated] = true means it was produced by the Test Mode
 * simulator; such events only ever live inside the Test Mode screen and never touch
 * NotificationManager, Telecom or any real system service.
 */
data class IslandEvent(
    val id: String,
    val kind: IslandKind,
    val title: String,
    val subtitle: String,
    val progress: Float? = null,
    val simulated: Boolean,
)
