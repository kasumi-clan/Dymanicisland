package com.godly.island.renderer

import android.os.Build
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext

/**
 * LiquidGlassRenderer — public entry points.
 *
 *   SHADER path : AGSL fragment shader (port of the Godly-Watermark WebGL shader), Android 13+.
 *   CANVAS path : pure Compose Canvas — dark tinted body, top light, rim gradient. No refraction/blur.
 *
 * The glass is applied to a layer that contains the *backdrop*; crisp content (text, icons) must be
 * drawn on top of that layer, exactly like the overlay texture in the HTML original.
 */
object LiquidGlassRenderer {
    enum class Path { SHADER, CANVAS }

    val shaderSupported: Boolean
        get() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU

    /** Decides which path will really be used for this config + engine. */
    fun resolve(config: GlassConfig, engine: GlassEngine?): Path {
        return when (config.mode) {
            RenderMode.CANVAS -> Path.CANVAS
            RenderMode.SHADER, RenderMode.AUTO ->
                if (engine != null && engine.ready) Path.SHADER else Path.CANVAS
        }
    }
}

/** Compiles (once) and remembers the shader for the given quality. */
@Composable
fun rememberGlassEngine(quality: GlassQuality): GlassEngine {
    val context = LocalContext.current
    return remember(quality) { GlassEngine.create(context, quality) }
}

/**
 * Applies Liquid Glass to the region [box] of this layer.
 * [phase] / [shine] are lambdas so animating them does not recompose anything.
 */
fun Modifier.liquidGlass(
    config: GlassConfig,
    engine: GlassEngine?,
    box: (Size) -> GlassBox,
    phase: () -> Float = { 0f },
    shine: () -> Float = { -1f },
): Modifier {
    val path = LiquidGlassRenderer.resolve(config, engine)
    if (path == LiquidGlassRenderer.Path.SHADER && engine != null) {
        return this.graphicsLayer {
            engine.render(this, config, size.width, size.height, box(size), phase(), shine())
        }
    }
    return this.canvasGlass(config, box)
}

private fun a(v: Float): Float = v.coerceIn(0f, 1f)

internal fun Modifier.canvasGlass(config: GlassConfig, box: (Size) -> GlassBox): Modifier =
    drawWithContent {
        drawContent()
        val b = box(size)
        if (b.w <= 2f || b.h <= 2f) return@drawWithContent
        val topLeft = Offset(b.x, b.y)
        val sz = Size(b.w, b.h)
        val corner = CornerRadius(b.r, b.r)
        val dark = ((1f - config.transparency) * 0.85f).coerceIn(0f, 0.95f)
        val refl = config.reflection.coerceIn(0f, 2f)
        val bord = config.border.coerceIn(0f, 2f)

        // body (AMOLED tint)
        drawRoundRect(
            color = Color.Black.copy(alpha = a(0.30f + dark * 0.65f)),
            topLeft = topLeft,
            size = sz,
            cornerRadius = corner,
        )
        // top light
        drawRoundRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color.White.copy(alpha = a(0.16f * refl)), Color.Transparent),
                startY = b.y,
                endY = b.y + b.h * 0.6f,
            ),
            topLeft = topLeft,
            size = sz,
            cornerRadius = corner,
        )
        // rim / border
        val sw = if (b.h * 0.011f < 1f) 1f else b.h * 0.011f
        val rr = if (b.r - sw / 2f < 0f) 0f else b.r - sw / 2f
        drawRoundRect(
            brush = Brush.linearGradient(
                colors = listOf(
                    Color.White.copy(alpha = a(0.55f * bord)),
                    Color.White.copy(alpha = a(0.10f * bord)),
                    Color.White.copy(alpha = a(0.35f * bord)),
                ),
                start = topLeft,
                end = Offset(b.x + b.w, b.y + b.h),
            ),
            topLeft = Offset(b.x + sw / 2f, b.y + sw / 2f),
            size = Size(b.w - sw, b.h - sw),
            cornerRadius = CornerRadius(rr, rr),
            style = Stroke(width = sw),
        )
    }
