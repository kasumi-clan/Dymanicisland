package com.godly.island.core

import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.compose.runtime.mutableStateListOf
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Small in-app error log shown in Test Mode. Safe to call from any thread. */
object ErrorLog {
    private val main = Handler(Looper.getMainLooper())

    val lines = mutableStateListOf<String>()

    fun add(tag: String, message: String) {
        val time = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val line = "$time [$tag] $message"
        Log.e("GodlyIsland", line)
        main.post {
            lines.add(line)
            while (lines.size > 40) lines.removeAt(0)
        }
    }

    fun clear() {
        main.post { lines.clear() }
    }
}
