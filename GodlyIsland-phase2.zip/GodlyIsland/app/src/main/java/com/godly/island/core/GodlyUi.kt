package com.godly.island.core

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Pill button. filled = white button, otherwise outlined glass look. */
@Composable
fun GodlyButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    filled: Boolean = false,
) {
    val shape = RoundedCornerShape(50)
    val bg = if (filled) GodlyColors.Paper else Color.White.copy(alpha = 0.06f)
    val fg = if (filled) GodlyColors.Ink else GodlyColors.Paper
    Box(
        modifier = modifier
            .alpha(if (enabled) 1f else 0.35f)
            .clip(shape)
            .background(bg)
            .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.22f)), shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = text,
            color = fg,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
        )
    }
}

/** Small selectable chip. */
@Composable
fun GodlyChip(
    text: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    val shape = RoundedCornerShape(50)
    val bg = if (selected) GodlyColors.Paper else Color.Transparent
    val fg = if (selected) GodlyColors.Ink else GodlyColors.Paper
    Box(
        modifier = modifier
            .alpha(if (enabled) 1f else 0.35f)
            .clip(shape)
            .background(bg)
            .border(BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)), shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 13.dp, vertical = 7.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text = text, color = fg, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier) {
    Text(
        text = text,
        color = GodlyColors.Paper,
        fontSize = 15.sp,
        fontWeight = FontWeight.ExtraBold,
        modifier = modifier,
    )
}
