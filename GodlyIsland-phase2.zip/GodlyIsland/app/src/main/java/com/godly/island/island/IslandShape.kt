package com.godly.island.island

/** Island sizes in dp. For DUAL the size is per pill (one pill each side of the camera). */
enum class IslandShape(
    val label: String,
    val widthDp: Int,
    val heightDp: Int,
    val dual: Boolean = false,
) {
    HIDDEN("Hidden", 0, 0),
    MINI("Mini", 124, 36),
    EXPANDED("Expanded", 316, 72),
    FULL("Full", 352, 178),
    DUAL("Dual", 148, 36, dual = true),
}
