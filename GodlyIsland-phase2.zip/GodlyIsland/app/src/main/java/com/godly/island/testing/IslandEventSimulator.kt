package com.godly.island.testing

import com.godly.island.events.IslandEvent
import com.godly.island.events.IslandKind
import com.godly.island.island.IslandShape

/**
 * Produces FAKE events for Test Mode only.
 * It builds plain IslandEvent objects (simulated = true) that are handed to the in-app preview.
 * It never calls NotificationManager, Telecom, MediaSession or any system service, so nothing
 * real is posted, rung or sent.
 */
object IslandEventSimulator {

    /** Kinds whose progress is animated 0 -> 100% when simulated. */
    val animatedKinds: Set<IslandKind> = setOf(IslandKind.DOWNLOAD, IslandKind.AI_PROCESSING)

    fun sample(kind: IslandKind): IslandEvent = when (kind) {
        IslandKind.CALL_INCOMING -> make(kind, "Godly Test", "Cuộc gọi đến (giả lập)")
        IslandKind.CALL_ONGOING -> make(kind, "Godly Test", "Đang gọi • 02:14 (giả lập)")
        IslandKind.MUSIC -> make(kind, "Lofi Nights", "Test Artist (giả lập)", 0.42f)
        IslandKind.BATTERY_LOW -> make(kind, "Pin yếu 15%", "Hãy cắm sạc (giả lập)", 0.15f)
        IslandKind.CHARGING -> make(kind, "Sạc nhanh 68%", "Còn khoảng 24 phút (giả lập)", 0.68f)
        IslandKind.NOTIFICATION -> make(kind, "Tin nhắn mới", "Người gửi thử: xin chào! (giả lập)")
        IslandKind.TIMER -> make(kind, "Hẹn giờ 04:32", "Thời gian còn lại (giả lập)", 0.55f)
        IslandKind.NAVIGATION -> make(kind, "Rẽ trái sau 200 m", "Đường Test • ETA 12 phút (giả lập)")
        IslandKind.BLUETOOTH -> make(kind, "Tai nghe đã kết nối", "Godly Buds (giả lập)")
        IslandKind.DOWNLOAD -> make(kind, "Đang tải tệp", "godly-test.zip (giả lập)", 0f)
        IslandKind.AI_PROCESSING -> make(kind, "AI đang xử lý ảnh", "Khử nhiễu 4K (giả lập)", 0f)
    }

    /** Two simultaneous events for the Dual Island: music + timer. */
    fun dualSample(): List<IslandEvent> =
        listOf(sample(IslandKind.MUSIC), sample(IslandKind.TIMER))

    fun recommendedShape(kind: IslandKind): IslandShape = when (kind) {
        IslandKind.TIMER, IslandKind.CHARGING, IslandKind.BLUETOOTH -> IslandShape.MINI
        IslandKind.NAVIGATION -> IslandShape.FULL
        else -> IslandShape.EXPANDED
    }

    private fun make(kind: IslandKind, title: String, subtitle: String, progress: Float? = null) =
        IslandEvent(
            id = "sim-" + kind.name,
            kind = kind,
            title = title,
            subtitle = subtitle,
            progress = progress,
            simulated = true,
        )
}
