package com.godly.island.island

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.godly.island.events.IslandEvent
import com.godly.island.renderer.GlassBox
import com.godly.island.renderer.GlassConfig
import com.godly.island.renderer.GlassEngine
import com.godly.island.renderer.liquidGlass

/**
 * Island preview used by Test Mode (and later by the real overlay window).
 *
 * Layers: [backdrop] -> Liquid Glass (one or two pills) -> crisp content.
 * Size changes use spring physics. Long-press / swipe-up are reported through callbacks
 * (Test Mode maps them to "expand" and "dismiss").
 */
@Composable
fun IslandPreview(
    config: GlassConfig,
    engineA: GlassEngine,
    engineB: GlassEngine,
    shape: IslandShape,
    events: List<IslandEvent>,
    animateRipple: Boolean,
    shineTick: Int,
    backdrop: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    onSwipeUp: () -> Unit = {},
    onLongPress: () -> Unit = {},
) {
    val density = LocalDensity.current
    val sizeSpec = spring<Dp>(dampingRatio = 0.62f, stiffness = 380f)
    val w by animateDpAsState(shape.widthDp.dp, sizeSpec, label = "islandW")
    val h by animateDpAsState(shape.heightDp.dp, sizeSpec, label = "islandH")
    val dual by animateFloatAsState(
        if (shape.dual) 1f else 0f,
        spring(dampingRatio = 0.7f, stiffness = 300f),
        label = "islandDual",
    )
    val wd = if (w < 0.dp) 0.dp else w
    val hd = if (h < 0.dp) 0.dp else h

    // ripple phase only runs while asked to (no endless GPU work when idle)
    val phase = remember { mutableFloatStateOf(0f) }
    LaunchedEffect(animateRipple) {
        if (animateRipple) {
            val t0 = withFrameNanos { it }
            while (true) {
                withFrameNanos { now -> phase.floatValue = (now - t0) / 1_000_000_000f * 0.9f }
            }
        }
    }
    // one-shot shine sweep every time shineTick changes
    val shine = remember { Animatable(-1f) }
    LaunchedEffect(shineTick) {
        if (shineTick > 0) {
            shine.snapTo(0f)
            shine.animateTo(1f, tween(1100, easing = LinearOutSlowInEasing))
            shine.snapTo(-1f)
        }
    }

    val gap = 56.dp
    val topMargin = 12.dp
    val wPx = with(density) { wd.toPx() }
    val hPx = with(density) { hd.toPx() }
    val gapPx = with(density) { gap.toPx() }
    val topPx = with(density) { topMargin.toPx() }
    val maxR = with(density) { 38.dp.toPx() }
    val dragPx = with(density) { 24.dp.toPx() }
    val radius = if (hPx / 2f < maxR) hPx / 2f else maxR

    val boxMain: (Size) -> GlassBox = { size ->
        val cx = size.width / 2f
        GlassBox.safe(cx - wPx / 2f + (-gapPx / 2f - wPx / 2f) * dual, topPx, wPx, hPx, radius)
    }
    val boxRight: (Size) -> GlassBox = { size ->
        val cx = size.width / 2f
        GlassBox.safe(cx + gapPx / 2f, topPx, wPx * dual, hPx, radius)
    }

    val longPress by rememberUpdatedState(onLongPress)
    val swipeUp by rememberUpdatedState(onSwipeUp)

    BoxWithConstraints(
        modifier
            .fillMaxWidth()
            .height(250.dp)
            .clip(RoundedCornerShape(22.dp))
            .pointerInput(Unit) {
                detectTapGestures(onLongPress = { longPress() })
            }
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -dragPx) swipeUp() },
                    onVerticalDrag = { _, dy -> total += dy },
                )
            },
    ) {
        val centerX = maxWidth / 2
        val glassOn = hPx > 2f && wPx > 2f

        // glass layers: B (outer, right pill) wraps A (inner, main pill). Each effect only
        // touches its own box and returns every other pixel unchanged.
        Box(
            Modifier
                .fillMaxSize()
                .then(
                    if (glassOn && dual > 0.02f) {
                        Modifier.liquidGlass(config, engineB, boxRight, { phase.floatValue }, { shine.value })
                    } else {
                        Modifier
                    },
                ),
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .then(
                        if (glassOn) {
                            Modifier.liquidGlass(config, engineA, boxMain, { phase.floatValue }, { shine.value })
                        } else {
                            Modifier
                        },
                    ),
            ) {
                backdrop()
            }
        }

        // crisp content on top of the glass (never refracted, like the overlay texture in the HTML)
        if (hd > 6.dp) {
            val mainX = centerX - wd / 2 + (-(gap / 2) - wd / 2) * dual
            Box(
                Modifier
                    .offset(x = mainX, y = topMargin)
                    .size(wd, hd)
                    .clipToBounds(),
            ) {
                IslandContent(events.getOrNull(0), shape)
            }
            if (dual > 0.02f) {
                Box(
                    Modifier
                        .offset(x = centerX + gap / 2, y = topMargin)
                        .size(wd * dual, hd)
                        .alpha(dual.coerceIn(0f, 1f))
                        .clipToBounds(),
                ) {
                    IslandContent(events.getOrNull(1), IslandShape.DUAL)
                }
            }
        }
    }
}

@Composable
private fun IslandContent(event: IslandEvent?, shape: IslandShape) {
    Crossfade(targetState = event, animationSpec = tween(220), label = "islandEvent") { ev ->
        if (ev != null) {
            when (shape) {
                IslandShape.MINI, IslandShape.DUAL -> CompactContent(ev)
                IslandShape.EXPANDED -> ExpandedContent(ev)
                IslandShape.FULL -> FullContent(ev)
                IslandShape.HIDDEN -> Unit
            }
        }
    }
}

@Composable
private fun CompactContent(ev: IslandEvent) {
    Row(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Glyph(ev, 22.dp)
        Text(
            text = ev.title,
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
    }
}

@Composable
private fun ExpandedContent(ev: IslandEvent) {
    Row(
        Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Glyph(ev, 40.dp)
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(
                text = ev.title,
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                text = ev.subtitle,
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            val p = ev.progress
            if (p != null) ProgressBar(p)
        }
    }
}

@Composable
private fun FullContent(ev: IslandEvent) {
    Column(
        Modifier
            .fillMaxSize()
            .padding(18.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Glyph(ev, 48.dp)
            Column {
                Text(
                    text = ev.title,
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.ExtraBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = ev.subtitle,
                    color = Color.White.copy(alpha = 0.72f),
                    fontSize = 12.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
            }
        }
        val p = ev.progress
        if (p != null) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                ProgressBar(p)
                Text(
                    text = "${(p * 100f).toInt()}%",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 11.sp,
                )
            }
        }
        val tag = if (ev.simulated) "${ev.kind.label.uppercase()}  •  SIMULATED" else ev.kind.label.uppercase()
        Text(text = tag, color = Color.White.copy(alpha = 0.5f), fontSize = 10.sp)
    }
}

@Composable
private fun Glyph(ev: IslandEvent, size: Dp) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.16f))
            .border(1.dp, Color.White.copy(alpha = 0.28f), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text = ev.kind.glyph,
            color = Color.White,
            fontSize = (size.value * 0.5f).sp,
            fontWeight = FontWeight.Bold,
        )
    }
}

@Composable
private fun ProgressBar(progress: Float) {
    val p = progress.coerceIn(0f, 1f)
    Box(
        Modifier
            .fillMaxWidth()
            .height(4.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.18f)),
    ) {
        Box(
            Modifier
                .fillMaxHeight()
                .fillMaxWidth(p)
                .background(Color.White),
        )
    }
}
